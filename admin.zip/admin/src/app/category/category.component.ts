 import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import CategoryService from '../category.service'

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  public category :any = [];

  constructor(private http:HttpClient) { 
    

  }  
      save(frm:NgForm){
   console.log(frm.value)
    this.http.post("http://localhost:8080/category/save",frm.value).subscribe(data=>{
        this.category.push(data)
    })
  }

  ngOnInit(): void {
    
      this.http.get("http://localhost:8080/category/load").subscribe(data=>{
        this.category = data
      });
    }
  
  }

  
