import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import CategoryService from '../category.service'

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  public category :any = [];

  constructor(private http:HttpClient) { 
    console.log("hello")

  }  
      save(frm:NgForm){
   console.log(frm.value)
    this.http.post("http://localhost:8080/category/save",frm.value).subscribe(data=>{
        this.category.push(data)
    })
  }

  ngOnInit(): void {
    
      this.http.get("http://localhost:8080/category/load").subscribe(data=>{
        this.category = data
      });
    }
  
}