import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

//import {server} from '../../package.json'

@Injectable({
  providedIn: 'root'
})
export default class CategoryService 
{
  constructor(private http:HttpClient) { }

  public getCategory() : Observable<any>
  {
    return this.http.get(`localhost:8080/category/load`)
  }
  public saveCategory(data:any) : Observable<any>
  {
    return this.http.post(`localhost:8080/category/save`,data)
  }
  
}