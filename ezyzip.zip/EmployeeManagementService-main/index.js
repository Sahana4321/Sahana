const express = require("express");

const swaggerJsdoc = require("swagger-jsdoc");

const swaggerUi = require("swagger-ui-express");



const app = express();

const bodyParser = require("body-parser");

const usersRoutes = require("./routes/users.route");



app.use(bodyParser.json());



/** Swagger Initialization - START */

const swaggerOption = {

  swaggerDefinition: (swaggerJsdoc.Options = {

    info: {

      title: "Voting Project",

      description: " Voting API ",

     

      servers: ["http://localhost:3000/"],

    },

  }),

  apis: ["index.js", "./routes/*.js"],

};



const swaggerDocs = swaggerJsdoc(swaggerOption);

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

/** Swagger Initialization - END */



app.use("/users", usersRoutes);



app.listen(3000, () => {

  console.log("Connected");

});

