const usersController = require("../controllers/users.controller");
var express = require("express");
var router = express.Router();
router.post("/register", usersController.register);

/**

* @swagger

* /users/register:

*   post:

*      description: User Registration

*      tags:

*          - users

*      parameters:

*          - in: body

*            name: User

*            description: User data

*            schema:

*              type: object

*              required:

*                 - firstName

*                 - lastName

*                 - emailId

*                 - password

*              properties:

*                  firstName:

*                      type: string

*                      minLength: 1

*                      maxLength: 45

*                      

*                  lastName:

*                      type: string

*                      minLength: 1

*                      maxLength: 45

*                      

*                  emailId:

*                      type: string

*                      minLength: 1

*                      maxLength: 100

*                      

*                  password:

*                      type: string

*                      minLength: 1

*                      maxLength: 45

*                      

*      responses:

*          '200':

*              description: Registration Successfully

*          '201':

*              description: Kindly fill the details correctly

*          

*/
//router.post("/login", usersController.login);
module.exports = router;